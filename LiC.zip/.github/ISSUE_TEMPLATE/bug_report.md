---
name: Bug report
about: Create a report to help us improve
title: "[BUG]"
labels: ''
assignees: ''

---

### Expected behavior

### Actual behavior

### Reproduction steps

### Please provide the following
*   Java Version:
*   exist-db version:
*   LiC version:
*   OS version: 
