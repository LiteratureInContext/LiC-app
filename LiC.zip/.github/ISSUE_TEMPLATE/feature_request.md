---
name: Feature request
about: Suggest an idea
title: ''
labels: enhancement
assignees: ''

---

### Your Ideal Solution

### Any Alternative Options

### Additional Context